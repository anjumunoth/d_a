import { Component } from '@angular/core';
import { Products } from '../products';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent {
  productsArr:Products[];
  showEditProductPrice:boolean;
  selectedProduct:Products | null;
  constructor()
  {
    this.productsArr=[];
    this.productsArr.push(new Products(101,"Apple Mac","Apple mac 128gb, white colour",123456,12,"./assets/images/macBook.jpg"));
    this.productsArr.push(new Products(102,"Dell Latitude","Dell Latitude, white colour",111111,2,"./assets/images/dellLatitude.jpg"));
    this.productsArr.push(new Products(103,"Lenovo Idea Pad","Lenovo Idea Pad 128gb, white colour",73456,5,"./assets/images/lenovoIdeaPad.jpg"));
    this.productsArr.push(new Products(104,"Samsung Galaxy Book","Samsung Galaxy Book 128gb, white colour",122222,12,"./assets/images/samsunggalaxyBook.jpg"));
    this.showEditProductPrice=false;
    this.selectedProduct=null
  }
  editPriceEventHandler(selectProductObj:Products)
  {
    this.showEditProductPrice=true;
    this.selectedProduct=selectProductObj;
  }
}
