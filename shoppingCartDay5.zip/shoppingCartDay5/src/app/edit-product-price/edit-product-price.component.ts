import { Component,Input } from '@angular/core';
import { Products } from '../products';

@Component({
  selector: 'app-edit-product-price',
  templateUrl: './edit-product-price.component.html',
  styleUrls: ['./edit-product-price.component.css']
})
export class EditProductPriceComponent {
@Input() selectedProduct:Products | null;
myString:string;
temp:boolean;
constructor()
{
  this.selectedProduct=null;
  this.myString="hello";
  this.temp=true;
}
}
