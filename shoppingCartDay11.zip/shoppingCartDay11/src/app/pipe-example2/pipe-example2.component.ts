import { Component } from '@angular/core';

@Component({
  selector: 'app-pipe-example2',
  templateUrl: './pipe-example2.component.html',
  styleUrls: ['./pipe-example2.component.css']
})
export class PipeExample2Component {

}
