import { FormControl } from "@angular/forms";

const users=['asha','karan'];

export function checkForUserName(control:FormControl)
{
  let userName=control.value;
  console.log("Username",userName);
  if(userName)
  {
        if(users.indexOf(userName) >=0)
        {
            // userName Exists
            return (
                {
                    checkForUserName:true,
                    
                }
            )
        }
        else
        {
            // userName does not exists
            return null;
        }
  }
  return null;
      
}
