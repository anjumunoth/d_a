import { Component } from '@angular/core';

@Component({
  selector: 'app-payment-by-wallet',
  templateUrl: './payment-by-wallet.component.html',
  styleUrls: ['./payment-by-wallet.component.css']
})
export class PaymentByWalletComponent {

}
