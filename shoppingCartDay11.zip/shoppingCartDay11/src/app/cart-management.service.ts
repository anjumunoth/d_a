import { Injectable } from '@angular/core';
import { CartProduct } from './cart-product';

@Injectable()
export class CartManagementService {
  cartArr:Array<CartProduct>;
  constructor() {
    this.cartArr=[];
   }
   addCartProduct(newCartProduct:CartProduct)
   {
      var isAlreadyPresent=this.checkIfCartProductExists(newCartProduct)  
      if(isAlreadyPresent)
      {
          return false;
      }  
      this.cartArr.push(newCartProduct);
      return true;
   }
   removeCartProduct(cartProductToBeRemoved:CartProduct)
   {

   }
   updateCartProduct(cartProductToBeUpdated:CartProduct)
   {

   }
   checkIfCartProductExists(ct:CartProduct)
   {
    return true;
   }
}
