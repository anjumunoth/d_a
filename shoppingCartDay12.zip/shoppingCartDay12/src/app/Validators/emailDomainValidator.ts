import { FormControl } from "@angular/forms";

export function emailDomainValidator (control:FormControl)
{
  let email=control.value;
  if(email && email.indexOf('@') !=-1)
  {
    // var str=asha@gmail.com;
    // var arr=str.split('@);
    // arr[0]="asha";
    // arr[1]="gmail.com"

    let domainName=email.split('@')[1];
    if(domainName !== 'deloitte.com')
    {
      // raise a error for the validation
      // return a Validation error object with the error Name: appEmailDomainValidator
      return ({
        appEmailDomainValidator:{
          parsedDomain:domainName,
          actualDomail: "deloitte.com"
        }
      })
    }
    
  }
  return null;
      
}
