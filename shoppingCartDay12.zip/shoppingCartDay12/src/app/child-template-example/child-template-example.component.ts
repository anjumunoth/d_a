import { Component,Input } from '@angular/core';

@Component({
  selector: 'app-child-template-example',
  templateUrl: './child-template-example.component.html',
  styleUrls: ['./child-template-example.component.css']
})
export class ChildTemplateExampleComponent {
@Input() customTemplate:any;
@Input() customTemplate2:any;

}
