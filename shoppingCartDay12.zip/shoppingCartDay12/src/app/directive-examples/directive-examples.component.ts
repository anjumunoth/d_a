import { Component } from '@angular/core';

@Component({
  selector: 'app-directive-examples',
  templateUrl: './directive-examples.component.html',
  styleUrls: ['./directive-examples.component.css']
})
export class DirectiveExamplesComponent {
  myColor:string;
  myFontColor:string;
  constructor()
  {
    this.myColor="violet";
    this.myFontColor="red";
  }
}
