import { Component } from '@angular/core';
import { CartProduct } from '../cart-product';
import { CartManagementService } from '../cart-management.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent {
  cartArr:Array<CartProduct>;
  quantitySelected:number=1;
  selProduct:CartProduct| any;
  showQuantityEdit:boolean;
  constructor(public cartManagementService:CartManagementService)
  {
    this.cartArr=cartManagementService.getAllCartProducts();
    this.selProduct={};
    this.showQuantityEdit=false;
  }
  removeCartProductEventHandler(cartObjToBeRemoved:CartProduct)
  {
    var result=this.cartManagementService.removeCartProduct(cartObjToBeRemoved);
    if(result)
    {
      this.cartArr=this.cartManagementService.getAllCartProducts(); 
    }

  }
  editCartProductEventHandler(cartObjToBeUpdated:CartProduct)
  {

    this.selProduct=cartObjToBeUpdated;
    this.showQuantityEdit=true;
    this.quantitySelected=cartObjToBeUpdated.quantitySelected || 1;
  }
  confirmCartProductEventHandler(productWithConfirmedQuantity:CartProduct)
  {
    console.log("Product confirmed",productWithConfirmedQuantity)
    productWithConfirmedQuantity.quantitySelected=this.quantitySelected;
    var result=this.cartManagementService.updateCartProduct(productWithConfirmedQuantity);
    console.log("Result of storing on db",result);
    if(result)
    {
      this.cartArr=this.cartManagementService.getAllCartProducts(); 
    }
    this.showQuantityEdit=false;
  }
  changeQuantityEventHandler(op: string) {
    if (op === "inc") {
      if (this.quantitySelected < this.selProduct.quantity) {
        this.quantitySelected++;
      }
    }
    else {
      if (this.quantitySelected > 1) {
        this.quantitySelected--;
      }
    }
  }

}
