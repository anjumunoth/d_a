import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { UserManagementService } from '../user-management.service';
import { emailDomainValidator } from "../Validators/emailDomainValidator"
import { passwordMustMatchValidator } from "../Validators/passwordMustMatch.validator"

@Component({
  selector: 'app-register-using-reactive-forms',
  templateUrl: './register-using-reactive-forms.component.html',
  styleUrls: ['./register-using-reactive-forms.component.css']
})
export class RegisterUsingReactiveFormsComponent {

  registerForm: FormGroup;
  userNameControl: FormControl;
  emailIdControl: FormControl;
  passwordControl: FormControl;
  confirmPasswordControl: FormControl;
  isSubmitted:boolean

  constructor(private formBuilder:FormBuilder,public userManagement:UserManagementService) {
    this.isSubmitted=false;
    this.userNameControl = new FormControl('', Validators.compose([Validators.required, Validators.minLength(4), Validators.maxLength(16)]));

    this.emailIdControl = new FormControl('', [Validators.required, Validators.pattern('^[_A-Za-z0-9-\+]+(\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9]+)*(\.[A-Za-z]{2,})$')]);
    this.passwordControl = new FormControl('', Validators.required);
    this.confirmPasswordControl = new FormControl('', Validators.required);
    this.registerForm = this.formBuilder.group({
      userName: this.userNameControl,
      emailId: this.emailIdControl,
      password: new FormControl('', Validators.required),
      confirmPassword: this.confirmPasswordControl

    },
      {
        validators:passwordMustMatchValidator('password','confirmPassword')
      }
    )
    this.registerForm.patchValue({password:"asha"})



  }
  submitEventHandler() {
  
    if(this.registerForm.invalid)
    {
      return;
    }
    
    //send the data to the server
    // Post request to the server with the entered details in the form
    // Can i add the post request here -- NO
    //Reasons:1. For security reasons
    //2. Seperation of concerns
    // Component -- Special Directive with a view attached; bridge between the model and view
    // model should be stored elsewhere and only accessed here
    //3. reusability of model
    //4. request, response -- async operation
    //5.no async operation (change the model data)-- outside the component
    // Business logic -- apply some transformation to the data before being sent and after receiving it from the server
    //6. No business logic in the component
    this.userManagement.createNewUser(this.registerForm.get('userName')?.value,this.registerForm.get('password')?.value,this.registerForm.get('emailId')?.value)
    var isUserAdditionSuccessful:boolean=this.userManagement.saveUser();
    if (isUserAdditionSuccessful)
    {
      this.isSubmitted=true;
      alert("Form submission successful");
      console.log("Values entered in the form",this.registerForm.value);
      this.registerForm.reset();
    }
    else
    {
      this.isSubmitted=false;
      alert("User name already exists");
      if(this.registerForm !== null)
      {
        this.registerForm.get("password")?.setValue("");
        this.registerForm.get("confirmPassword")?.setValue("");
        this.registerForm.get('userName')?.setErrors({userNameExists:true});
      }
    }
  }

  get userName() {
    return this.registerForm.get('userName')
  }

  get password() {
    return this.registerForm.get('password')
  }
  get emailId() {
    return this.registerForm.get('emailId')
  }
  get confirmPassword() {
    return this.registerForm.get('confirmPassword')
  }
}
