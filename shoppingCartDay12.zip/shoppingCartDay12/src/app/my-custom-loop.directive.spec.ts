import { MyCustomLoopDirective } from './my-custom-loop.directive';

describe('MyCustomLoopDirective', () => {
  it('should create an instance', () => {
    const directive = new MyCustomLoopDirective();
    expect(directive).toBeTruthy();
  });
});
