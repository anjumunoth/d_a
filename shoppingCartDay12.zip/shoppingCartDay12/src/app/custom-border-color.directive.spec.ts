import { CustomBorderColorDirective } from './custom-border-color.directive';

describe('CustomBorderColorDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomBorderColorDirective();
    expect(directive).toBeTruthy();
  });
});
