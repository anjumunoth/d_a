import { InputTextBoxValidationDirectiveDirective } from './input-text-box-validation-directive.directive';

describe('InputTextBoxValidationDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new InputTextBoxValidationDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
