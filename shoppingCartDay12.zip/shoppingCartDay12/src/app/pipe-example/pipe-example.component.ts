import { Component } from '@angular/core';
import { Products } from '../products';

@Component({
  selector: 'app-pipe-example',
  templateUrl: './pipe-example.component.html',
  styleUrls: ['./pipe-example.component.css']
})
export class PipeExampleComponent {
  imgUrl:string;
  imgUrl1:string;
  product:Object;
  constructor()
  {
    this.imgUrl="./assets/images/dellLatitude.jpg";
    this.imgUrl1=""
    this.product={productId:101,productName:"apple",description:"apple iphone",price:6778.67,quantity:45,imgUrl:""};
  }
}
