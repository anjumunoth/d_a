import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class TalkWithServerService {
  serverUrlEndPoint="https://jsonplaceholder.typicode.com/users"
  constructor(private httpClient:HttpClient) { }

  getUsers()
  {
    this.httpClient.get(this.serverUrlEndPoint).pipe(
      retry(1),
      catchError(this.handleError)
      
    )
  }

  handleError(err:any)
  {
    let msg:any;
    if(err.error instanceof ErrorEvent)
    {
      msg=err.error.message
    }
    else
    {
      msg=`Error code : ${err.status} ; Msg : ${err.message}`
    }
    console.log(msg);
    return throwError(()=>{
      console.log(msg);
    });

  }
}
