import { Injectable } from '@angular/core';
import { CartProduct } from './cart-product';

@Injectable()
export class CartManagementService {
  cartArr:Array<CartProduct>;
  constructor() {
    this.cartArr=[];
   }
   getAllCartProducts()
   {
      return this.cartArr;
   }
   addCartProduct(newCartProduct:CartProduct)
   {
      var isAlreadyPresent=this.checkIfCartProductExists(newCartProduct)  
      if(isAlreadyPresent)
      {
         var pos=this.cartArr.findIndex(item => item.productId === newCartProduct.productId);
         this.cartArr[pos].quantitySelected=(this.cartArr[pos].quantitySelected ||0)+(newCartProduct.quantitySelected || 0);
         return true;
      }  
      this.cartArr.push(newCartProduct);
      return true;
   }
   removeCartProduct(cartProductToBeRemoved:CartProduct)
   {
      var pos=this.cartArr.findIndex(item => item.productId === cartProductToBeRemoved.productId);
      if(pos >=0)
      {
         this.cartArr.splice(pos,1);
         return true;
      }
      else
      {
         return false;
      }
   }
   updateCartProduct(cartProductToBeUpdated:CartProduct)
   {
      var pos=this.cartArr.findIndex(item => item.productId === cartProductToBeUpdated.productId);
      if(pos >=0)
      {
         this.cartArr.splice(pos,1,cartProductToBeUpdated);
         return true;
      }
      else
      {
         return false;
      }
   }
   checkIfCartProductExists(ct:CartProduct)
   {
      
      var pos=this.cartArr.findIndex(item => item.productId === ct.productId);
      if(pos >= 0)
      {
         return true;
      }
      else
      {
         return false;
      }
   }
}
