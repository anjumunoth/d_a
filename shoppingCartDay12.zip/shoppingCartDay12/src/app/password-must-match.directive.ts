import { Directive,Input } from '@angular/core';
import { AbstractControl, FormGroup, NG_VALIDATORS,ValidationErrors,Validator } from '@angular/forms';
import {passwordMustMatchValidator} from "./Validators/passwordMustMatch.validator"
@Directive({
  selector: '[appPasswordMustMatch]',
  providers:[{
    provide: NG_VALIDATORS,
    useExisting:PasswordMustMatchDirective,
    multi:true
  }]
})
export class PasswordMustMatchDirective implements Validator {
@Input() appPasswordMustMatch:string[];
  constructor() { 
    this.appPasswordMustMatch=[];
  }
  validate(formGroup:FormGroup): ValidationErrors | null {
    return passwordMustMatchValidator(this.appPasswordMustMatch[0],this.appPasswordMustMatch[1])(formGroup);
  }
  

}
