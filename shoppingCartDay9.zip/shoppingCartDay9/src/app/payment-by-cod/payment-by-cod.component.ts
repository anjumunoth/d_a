import { Component } from '@angular/core';

@Component({
  selector: 'app-payment-by-cod',
  templateUrl: './payment-by-cod.component.html',
  styleUrls: ['./payment-by-cod.component.css']
})
export class PaymentByCODComponent {

}
