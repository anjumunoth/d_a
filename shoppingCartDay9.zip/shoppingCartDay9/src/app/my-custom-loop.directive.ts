import { Input, SimpleChanges, Directive, ViewContainerRef, TemplateRef, OnChanges, OnInit } from '@angular/core';

@Directive({
  selector: '[appMyCustomLoop]'
})
export class MyCustomLoopDirective implements OnChanges, OnInit {
  @Input() appMyCustomLoopOf: Array<number>;
  constructor(private container: ViewContainerRef, private template: TemplateRef<any>) {
    this.appMyCustomLoopOf = [];
  }
  ngOnInit() {
    
  }
  ngOnChanges(change: SimpleChanges) {
    this.container.clear();
    /* for(let val of this.appMyCustomLoopOf)
    {
      this.container.createEmbeddedView(this.template,{
        $implicit:val,
        index: this.appMyCustomLoopOf.indexOf(val)
      });
    } */

    for(let i=0;i< this.appMyCustomLoopOf.length;i++)
    {
      
      this.container.createEmbeddedView(this.template,{
        $implicit:this.appMyCustomLoopOf[i],
        index: i,
        first: (i==0),
        last: (i== (this.appMyCustomLoopOf.length-1))
      });
    }

  }
}

/*
<ul>
  <li *ngFor="let num of numArr">
  {{num}}
  </li>
</ul>

<tr *ngFor="let emp of empArr">
  <td>{{emp.empId}}</td>
  <td>{{emp.empName}}></td>
</tr>

Lifecycle methods
1. constructor
2. @Input
3. onChanges
4. onInit


 */
