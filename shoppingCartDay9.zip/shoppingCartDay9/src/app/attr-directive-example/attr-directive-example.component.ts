import { Component } from '@angular/core';

@Component({
  selector: 'app-attr-directive-example',
  templateUrl: './attr-directive-example.component.html',
  styleUrls: ['./attr-directive-example.component.css']
})
export class AttrDirectiveExampleComponent {

  colorTheme:string;
  customStyle:Object;
  customClass:string;
  customClass1:string[];
  customClass2:Object;
  customClass3:Object;
  constructor()
  {
    this.colorTheme="dark";
    this.customStyle={
      'text-align':this.colorTheme === "dark" ?"center":"right",
      'border':this.colorTheme=== "dark"? "5px solid pink" : "5px solid black"
    }
    console.log(this.customStyle);
    this.customClass=this.colorTheme==='dark' ? 'bg-dark text-white' : 'bg-white text-dark';
    if(this.colorTheme === "dark")
    {
      this.customClass1=['bg-dark', 'text-white'];
      this.customClass2={'bg-dark':true,'text-white':true}
    }
    else
    {
      this.customClass1=['bg-white', 'text-dark'];
      this.customClass2={'bg-white':true,'text-dark':true}
    }
    this.customClass3={
      'bg-dark':this.colorTheme==='dark' ? true : false,
      'bg-white':this.colorTheme!=='dark' ? true : false,
      'text-white':this.colorTheme ==="dark"?true:false,
      'text-dark':this.colorTheme !=="dark"?true:false,
    }

  }
}
