import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PipeExample2Component } from './pipe-example2.component';

describe('PipeExample2Component', () => {
  let component: PipeExample2Component;
  let fixture: ComponentFixture<PipeExample2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PipeExample2Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PipeExample2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
