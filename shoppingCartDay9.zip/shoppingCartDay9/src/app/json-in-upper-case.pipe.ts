import { Pipe, PipeTransform } from '@angular/core';
import { Products } from './products';
import {CurrencyPipe,UpperCasePipe} from "@angular/common";

@Pipe({
  name: 'jsonInUpperCase'
})
export class JsonInUpperCasePipe implements PipeTransform {
  transform(value: any,CurrencyCode:string, ...args: string[]): string {
    var newObj={...value};
    var upObj=new UpperCasePipe();
    newObj.productName=upObj.transform(newObj.productName);

    var cPipeObj=new CurrencyPipe("en-CA");
    newObj.price=cPipeObj.transform(newObj.price,CurrencyCode);
    return JSON.stringify(newObj);
      
    }
   
  
}
