import { Component,EventEmitter,Input,Output} from '@angular/core';

@Component({
  selector: 'app-change-size',
  templateUrl: './change-size.component.html',
  styleUrls: ['./change-size.component.css']
})
export class ChangeSizeComponent {
@Input() cdTextSize:number=24;
@Output() cdTextSizeChange:EventEmitter<number>;
constructor()
{
  this.cdTextSizeChange=new EventEmitter<number>();
}
incSize()
{
  this.cdTextSize++;
  this.emitSize();
}
decSize()
{
  this.cdTextSize--;
  this.emitSize();
}
emitSize()
{
  this.cdTextSizeChange.emit(this.cdTextSize);
}

}
