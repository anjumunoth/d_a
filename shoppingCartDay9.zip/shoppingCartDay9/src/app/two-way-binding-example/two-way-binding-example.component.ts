import { Component } from '@angular/core';
import { Products } from '../products';

@Component({
  selector: 'app-two-way-binding-example',
  templateUrl: './two-way-binding-example.component.html',
  styleUrls: ['./two-way-binding-example.component.css']
})
export class TwoWayBindingExampleComponent {
  fName:string="";
  lName:string="";
  userEmail:string="";
  qualification:string="";
  colors:Array<string>=["red","green","blue"]
  myColor:string;
  textSize:number=24;
  productsArr:Array<Products>
  showEditProductName:boolean;
  selectedProduct:Products| any
  constructor()
  {
    this.myColor=this.colors[0];
    this.productsArr=[];
    this.productsArr.push(new Products(101,"Apple Mac","Apple mac 128gb, white colour",123456,12,"./assets/images/macBook.jpg"));
    this.productsArr.push(new Products(102,"Dell Latitude","Dell Latitude, white colour",111111,2,"./assets/images/dellLatitude.jpg"));
    this.productsArr.push(new Products(103,"Lenovo Idea Pad","Lenovo Idea Pad 128gb, white colour",73456,5,"./assets/images/lenovoIdeaPad.jpg"));
    this.productsArr.push(new Products(104,"Samsung Galaxy Book","Samsung Galaxy Book 128gb, white colour",122222,12,"./assets/images/samsunggalaxyBook.jpg"));
    this.showEditProductName=false;
    this.selectedProduct={};
  }
  setFNameEventHandler(ev:any)
  {
    this.fName=ev.target.value
  }
  editNameEventHandler(selProduct:Products)
  {
    this.showEditProductName=true;
    this.selectedProduct=selProduct;
  }
}
