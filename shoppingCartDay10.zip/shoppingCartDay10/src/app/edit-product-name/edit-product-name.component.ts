import { Component,EventEmitter,Input,OnInit,Output } from '@angular/core';
import { Products } from '../products';

@Component({
  selector: 'app-edit-product-name',
  templateUrl: './edit-product-name.component.html',
  styleUrls: ['./edit-product-name.component.css']
})
export class EditProductNameComponent implements OnInit {
  @Input() selProduct:Products| any;
  @Output() selProductChange:EventEmitter<Products>;
  updatedSelProduct:Products|any;
  constructor()
  {
    this.selProduct={};
    this.selProductChange=new EventEmitter<Products>();
  }
  ngOnInit(): void {
    this.updatedSelProduct={...this.selProduct};
  }
  
confirmEventHandler()
{
  //this.selProduct.productName=ev.target.value;
    console.log(this.updatedSelProduct);
    //this.selProduct=this.updatedSelProduct;// will change the reference
    this.selProduct.productName=this.updatedSelProduct.productName;
    this.selProductChange.emit(this.selProduct);
}
cancelEventHandler()
{
  this.selProductChange.emit(this.selProduct);
  

}
}
