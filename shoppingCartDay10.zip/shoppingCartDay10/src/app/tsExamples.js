var obj1={empId:101,empName:"sara"};
var obj2=obj1;// reference
obj2.empId=222;
console.log(obj1);//{empId:222,empName:"sara"};
console.log(obj2);//{empId:222,empName:"sara"};

function myFunc(emp1)
{
    emp1.empid=222;
}

myFunc(obj1);

// Make a Copy of  an object -- ES6 

var emp1={empId:101,empName:"sara"};
var emp2={...emp1};// spread operator 
emp2.empId=777;
console.log(emp1);//{empId:101,empName:"sara"};
console.log(emp2);//{empId:777,empName:"sara"};

var emp3={...emp1,salary:555};// spread operator 
console.log(emp3);//{empId:101,empName:"sara",salary:555};

var emp4={...emp1,empId:555};// spread operator 
console.log(emp4);//{empId:555,empName:"sara"};

var emp5={empId:555,...emp1};// spread operator 
console.log(emp5);//{empId:101,empName:"sara"};

var dept1={deptId:"d1",loc:"chn"}
var emp6={...emp1,...dept1};
console.log(emp6);//{empId:101,empName:"sara",deptId:"d1",loc:"chn"};


var emp7={...emp1,...emp2};
console.log(emp7);//{empId:777,empName:"sara"};

var arr1=[10,20,30];
var arr2=arr1;// reference
arr2[0]=100;
console.log(arr1);//[100,20,30]
console.log(arr2);//[100,20,30]

var arr3=[...arr1];
arr3[0]=444;
console.log(arr1);//[100,20,30]
console.log(arr3);//[444,20,30]

var arr4=[...arr1,20];
console.log(arr1);//[100,20,30]
console.log(arr4);//[100,20,30,20];


class Employee
{
    empId;
    empName
    constructor()
    {
        //best practice :  initialise it 
        //
    }
}







