import { Component,Input } from '@angular/core';
import { Products } from '../products';
@Component({
  selector: 'app-add-to-cart-using-get-set',
  templateUrl: './add-to-cart-using-get-set.component.html',
  styleUrls: ['./add-to-cart-using-get-set.component.css']
})
export class AddToCartUsingGetSetComponent {
  private _selectedProduct:Products| any;
@Input('selectedProduct')
public get selProduct()
{
  return this._selectedProduct;
}
public set selProduct(value)
{
  this._selectedProduct=value;
  this.quantitySelected=1;
}

quantitySelected:number
constructor()
{
  this._selectedProduct={};
  this.quantitySelected=1;
}
changeQuantityEventHandler(op: string) {
  if (op === "inc") {
    if (this.quantitySelected < this.selProduct.quantity) {
      this.quantitySelected++;
    }
  }
  else {
    if (this.quantitySelected > 1) {
      this.quantitySelected--;
    }
  }
}
}

/*
@Input()
 --- Used to access the data coming from the parent component
 --- Can use getter and setter 
 --- Can give alias name to the input property
 --- Can have multiple decorators
 --- After the constructor, @Input assignments happen 
 --- Usually done with property binding
 
@Output()
 -- Used to send data/control to the parent component
 -- Works always with events and event emitters
 -- Trigger the event
 -- can pass only a single value using a single @Output
 -- Can have multiple @output decorators
 -- Usually done with event bindings


 Is it always mandatory to have @Input decorator to receive data from parent
 Can also add the data from the parent as part of the decorator metadata

 Directives
 -- Structural directive - *ngFor, *ngIf , *ngSwitch
 -- Attribute directives -- ngClass, ngStyle
 -- Component -- Special directive with a view attached
 -- Custom directive 
*/