import { Component } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
  logoImgUrl="../../assets/deloitteLogo.png";
}

/*
Grid in bootstrap
Each row -12 column layout
img - occupy 4 cols -- col-4
h1 -- occupy 8 cols -- col-8


*/
