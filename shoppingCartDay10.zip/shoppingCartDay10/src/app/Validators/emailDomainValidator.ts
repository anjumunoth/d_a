import { FormControl } from "@angular/forms";

export function emailDomainValidator (control:FormControl)
{
  let email=control.value;
  if(email && email.indexOf('@') !=-1)
  {
    let domainName=email.split('@')[1];
    if(domainName !== 'deloitte.com')
    {
      // raise a error for the validation
      return ({
        appEmailDomainValidator:{
          parsedDomain:domainName,
          actualDomail: "deloitte.com"
        }
      })
    }
    
  }
  return null;
      
}
