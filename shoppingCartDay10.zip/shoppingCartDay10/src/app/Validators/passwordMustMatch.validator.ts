import { FormControl, FormGroup } from "@angular/forms";

export function passwordMustMatchValidator(controlName:string,matchingControlName:string)
{
    return (
        (formGroup:FormGroup)=>{
            console.log("FormGroup",formGroup.controls);
            const control=formGroup.controls[controlName]
            const matchingControl=formGroup.controls[matchingControlName]
            if( !control || !matchingControl)
            {
                // not initialised or not set
                return null;
            }
             if(control.errors || matchingControl.errors)
            {
                // if there are any others errors
                return null;
            } 
           

            if(control.value !== matchingControl.value)
            {
                matchingControl.setErrors({passwordMustMatch:true});
                return ({passwordMustMatch:true});
            }
            else
            {
                matchingControl.setErrors(null);
                return null;
            }

        }
    )
}