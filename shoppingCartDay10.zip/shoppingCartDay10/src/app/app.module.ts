import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { AddProductComponent } from './add-product/add-product.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { EditProductComponent } from './edit-product/edit-product.component';
import { EditProductPriceComponent } from './edit-product-price/edit-product-price.component';
import { AddToCartUsingGetSetComponent } from './add-to-cart-using-get-set/add-to-cart-using-get-set.component';
import { AttrDirectiveExampleComponent } from './attr-directive-example/attr-directive-example.component';
import { PaymentOptionsComponent } from './payment-options/payment-options.component';
import { PaymentByCODComponent } from './payment-by-cod/payment-by-cod.component';
import { PaymentByCardComponent } from './payment-by-card/payment-by-card.component';
import { PaymentByWalletComponent } from './payment-by-wallet/payment-by-wallet.component';
import { PaymentByNetBankingComponent } from './payment-by-net-banking/payment-by-net-banking.component';
import { MyBgColorDirective } from './my-bg-color.directive';
import { DirectiveExamplesComponent } from './directive-examples/directive-examples.component';
import { CustomBgColorDirective } from './custom-bg-color.directive';
import { CustomBorderColorDirective } from './custom-border-color.directive';
import { InputTextBoxValidationDirectiveDirective } from './input-text-box-validation-directive.directive';
import { MyCustomLoopDirective } from './my-custom-loop.directive';
import { CustomStructuralDirectivesExampleComponent } from './custom-structural-directives-example/custom-structural-directives-example.component';
import { MyToolTipDirective } from './my-tool-tip.directive';
import { MyToolTipExampleComponent } from './my-tool-tip-example/my-tool-tip-example.component';
import { TemplateExamplesComponent } from './template-examples/template-examples.component';
import { ParentTemplateExampleComponent } from './parent-template-example/parent-template-example.component';
import { ChildTemplateExampleComponent } from './child-template-example/child-template-example.component';
import { DefaultImagePipe } from './default-image.pipe';
import { PipeExampleComponent } from './pipe-example/pipe-example.component';
import { PipeExample2Component } from './pipe-example2/pipe-example2.component';
import { JsonInUpperCasePipe } from './json-in-upper-case.pipe';
import { TwoWayBindingExampleComponent } from './two-way-binding-example/two-way-binding-example.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ChangeSizeComponent } from './change-size/change-size.component';
import { EditProductNameComponent } from './edit-product-name/edit-product-name.component';
import { RegisterComponent } from './register/register.component';
import { EmailDomainValidatorDirective } from './email-domain-validator.directive';
import { PasswordMustMatchDirective } from './password-must-match.directive';
import { CheckForUserNameDirective } from './check-for-user-name.directive';
import { RegisterUsingReactiveFormsComponent } from './register-using-reactive-forms/register-using-reactive-forms.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    AddProductComponent,
    AddToCartComponent,
    EditProductComponent,
    EditProductPriceComponent,
    AddToCartUsingGetSetComponent,
    AttrDirectiveExampleComponent,
    PaymentOptionsComponent,
    PaymentByCODComponent,
    PaymentByCardComponent,
    PaymentByWalletComponent,
    PaymentByNetBankingComponent,
    MyBgColorDirective,
    DirectiveExamplesComponent,
    CustomBgColorDirective,
    CustomBorderColorDirective,
    InputTextBoxValidationDirectiveDirective,
    MyCustomLoopDirective,
    CustomStructuralDirectivesExampleComponent,
    MyToolTipDirective,
    MyToolTipExampleComponent,
    TemplateExamplesComponent,
    ParentTemplateExampleComponent,
    ChildTemplateExampleComponent,
    DefaultImagePipe,
    PipeExampleComponent,
    PipeExample2Component,
    JsonInUpperCasePipe,
    TwoWayBindingExampleComponent,
    ChangeSizeComponent,
    EditProductNameComponent,
    RegisterComponent,
    EmailDomainValidatorDirective,
    PasswordMustMatchDirective,
    CheckForUserNameDirective,
    RegisterUsingReactiveFormsComponent
  ],
  imports: [
    FormsModule,
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
