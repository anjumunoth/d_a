import { Directive } from '@angular/core';
import { FormControl, NG_VALIDATORS } from '@angular/forms';
import {emailDomainValidator} from "../app/Validators/emailDomainValidator";


@Directive({
  selector: '[appEmailDomainValidator]',
  providers:[{
    provide: NG_VALIDATORS,
    useValue: emailDomainValidator,
    multi:true
  }]
  

})
export class EmailDomainValidatorDirective {

  constructor() { }

}
