import { EmailDomainValidatorDirective } from './email-domain-validator.directive';

describe('EmailDomainValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new EmailDomainValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
