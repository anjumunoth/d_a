import { Component } from '@angular/core';
import { FormGroup,FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-register-using-reactive-forms',
  templateUrl: './register-using-reactive-forms.component.html',
  styleUrls: ['./register-using-reactive-forms.component.css']
})
export class RegisterUsingReactiveFormsComponent {

  registerForm:FormGroup;
  userName:FormControl;
  emailId:FormControl;
  password:FormControl;
  confirmPassword:FormControl;
  
  constructor()
  {
    this.userName=new FormControl('',Validators.required);
    this.emailId=new FormControl('',Validators.required);
    this.password=new FormControl('',Validators.required);
    this.confirmPassword=new FormControl('',Validators.required);
    this.registerForm=new FormGroup({
      userName:this.userName,
      emailId:this.emailId,
      password:new FormControl('',Validators.required),
      confirmPassword:this.confirmPassword
      
    })

    
  }
  submitEventHandler()
  {

  }
}
