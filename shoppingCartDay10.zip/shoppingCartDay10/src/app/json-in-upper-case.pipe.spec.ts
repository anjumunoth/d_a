import { JsonInUpperCasePipe } from './json-in-upper-case.pipe';

describe('JsonInUpperCasePipe', () => {
  it('create an instance', () => {
    const pipe = new JsonInUpperCasePipe();
    expect(pipe).toBeTruthy();
  });
});
