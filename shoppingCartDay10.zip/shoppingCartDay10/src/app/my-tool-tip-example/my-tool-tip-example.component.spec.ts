import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyToolTipExampleComponent } from './my-tool-tip-example.component';

describe('MyToolTipExampleComponent', () => {
  let component: MyToolTipExampleComponent;
  let fixture: ComponentFixture<MyToolTipExampleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyToolTipExampleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MyToolTipExampleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
