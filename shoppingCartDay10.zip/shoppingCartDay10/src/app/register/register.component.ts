import { Component } from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  user:any;
  emailPattern:string;
  strongPasswordPattern:string;
  isSubmitted:boolean;
  constructor()
  {
    this.strongPasswordPattern='^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$'
    this.emailPattern='^[_A-Za-z0-9-\+]+(\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9]+)*(\.[A-Za-z]{2,})$'
    this.user={
      userName:"",
      password:"",
      confirmPassword:"",
      emailId:""
    }
    this.isSubmitted=false;
  }
  onSubmitEventHandler()
  {
    this.isSubmitted=true;
  }
}
/*
ng-dirty -- value has been changed
ng-pristine -- value has not been changed

ng-touched -- value has been modified and blurred from the input control 
ng-untouched -- blur event has never occurred

ng-valid
ng-invalid

*/