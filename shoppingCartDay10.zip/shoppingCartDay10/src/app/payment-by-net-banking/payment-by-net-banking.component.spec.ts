import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentByNetBankingComponent } from './payment-by-net-banking.component';

describe('PaymentByNetBankingComponent', () => {
  let component: PaymentByNetBankingComponent;
  let fixture: ComponentFixture<PaymentByNetBankingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaymentByNetBankingComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PaymentByNetBankingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
