import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appInputTextBoxValidationDirective]'
})
export class InputTextBoxValidationDirectiveDirective {
  @Input('appInputTextBoxValidationDirective') textBoxLength: string;
  @HostListener('keypress') onKeyPressEventHandler() {
    this.changeBackground();
    return this.checkLength(this.el);
  }

  @HostListener('blur') onBlurEventHandler()
  {
    this.resetBackground();
  }
  constructor(private el: ElementRef) {
    console.log("Initial value in the text box" + this.el.nativeElement.value + " ***");
    this.textBoxLength = "";
  }
  resetBackground()
  {
    this.el.nativeElement.style.backgroundColor = "white";
  }
  changeBackground() {
    this.el.nativeElement.style.backgroundColor = "yellow";
  }
  checkLength(elementRef: ElementRef) {
    if (elementRef.nativeElement.value.length > (parseInt(this.textBoxLength) - 1)) {
      return false;
    }
    else {
      return true;
    }
  }

}
