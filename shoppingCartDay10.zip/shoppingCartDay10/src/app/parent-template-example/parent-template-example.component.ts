import { Component,ViewChild,TemplateRef,AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-parent-template-example',
  templateUrl: './parent-template-example.component.html',
  styleUrls: ['./parent-template-example.component.css']
})
export class ParentTemplateExampleComponent implements AfterViewInit {
  @ViewChild('parentTemplate') myTemplate:TemplateRef<HTMLElement> | null; 
  emp:any;
  constructor()
  {
    this.emp={empId:101,empName:"sara"};
    this.myTemplate=null;
  }
  ngAfterViewInit()
  {
    console.log(this.myTemplate);
  }
  changeCaseEventHandler()
  {
    this.emp.empName=this.emp.empName.toUpperCase();
  }
}

/*
Use cases of sending the template from parent to child
1. Send data and styling present in the parent component to the child
2. Instead of sending data seperately, send data and styling and validations, events flow to the child


@Input vs (passing template from parent to child) 
1. @Input -- pass only data
Passing Template -- Pass data from the parent, styling, events(with event handlers in the parent)

2. Limitation: Can't modify the template whereas the @Input can be modified
*/
