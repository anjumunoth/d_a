import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BindingExample2Component } from './binding-example2.component';

describe('BindingExample2Component', () => {
  let component: BindingExample2Component;
  let fixture: ComponentFixture<BindingExample2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BindingExample2Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BindingExample2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
