import { Component } from '@angular/core';

@Component({
  selector: 'del-binding-example2',
  templateUrl: './binding-example2.component.html',
  styleUrls: ["../binding-example3.component.css"]
})
export class BindingExample2Component {

}
