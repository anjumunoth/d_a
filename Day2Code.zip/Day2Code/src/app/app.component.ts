import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my-first-app';
  companyName:string="Spring people";
  colours:string[]=["red","green"];
  empObj={empId:101,empName:"sara"};
  projectArr=[{projectId:"P101",projectName:"Store Front",projectDescription:"E Commerce Application"},
{projectId:"P102",projectName:"CueBack",projectDescription:"Social Networking"},
{projectId:"P103",projectName:"Premium Access",projectDescription:"Digital Course Library"},
{projectId:"P104",projectName:"Freegal Music",projectDescription:"Libary of Songs"},
{projectId:"P105",projectName:"Comlink Data",projectDescription:"Data Science"}];

companyUrl="https://www.deloitte.com/global/en.html"
  constructor()
  {
    
  }
  calculateSquare(first:number):number
  {
      return first * first;
  }
}
