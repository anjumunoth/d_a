function myFunc1(p1:number,p2:number,f1:Function) {
    f1(p1,p2);
    // addNumbers(p1,p2);
}

myFunc1(10,20,function (a1:number,a2:number){console.log(a1+a2)});// 30

myFunc1(10,20,function (b1:string,b2:string){console.log(b1+b2)});//30


var empId=999
var emp2={
    empId:101,empName:"sara",
    display:function(){
        console.log("Inside the display")
        console.log("EmpId"+this.empId);// emp2.empId
        console.log("EmpName"+this.empName);
    },
    printDetails:()=>{
        console.log("Inside the printDetails")
        console.log("EmpId"+empId);;//lexical scope ; global scope
        console.log("EmpName"+this.empName);
         

    }

}
emp2.printDetails()


var arr:number[]=[10,20,30,40,50];
var resArr1=arr.map(function(item){
    return item*item;
})
var resArr=arr.map((item)=>item*item);
console.log(resArr);
console.log(arr);
/*
map --
-- always called on an array
-- iterate through elements of the array; execute the function passed as the first param
-- return an array (size same as the target array)
-- not modify the original array

*/

arr=[10,20,30,40,50];
// function which will return the index of a particular search element 

function searchIndex(inputArray: number[],searchValue: number ){
    
    return inputArray.indexOf(searchValue);    
}


var pos=arr.findIndex(item => item === 30);

var projectArr=
[{projectId:"P101",projectName:"Store Front",projectDescription:"E Commerce Application"},
{projectId:"P102",projectName:"CueBack",projectDescription:"Social Networking"},
{projectId:"P103",projectName:"Premium Access",projectDescription:"Digital Course Library"},
{projectId:"P104",projectName:"Freegal Music",projectDescription:"Libary of Songs"},
{projectId:"P105",projectName:"Comlink Data",projectDescription:"Data Science"}];

// return the first project position which starts with "C"

var pos =projectArr.findIndex(item => item.projectName.startsWith("C"));//1
var obj=projectArr.find(item => item.projectName.startsWith("C"));//{projectId:"P102",projectName:"CueBack",projectDescription:"Social Networking"},
console.log(pos);
console.log(obj);
var objArr=projectArr.filter(item => item.projectName.startsWith("C"));
// all the elements in the array which satisfies the predicate function as an array
[{projectId:"P102",projectName:"CueBack",projectDescription:"Social Networking"},
{projectId:"P105",projectName:"Comlink Data",projectDescription:"Data Science"}];
//var posArr=projectArr.filterIndex(item => item.projectName.startsWith("C"));//error no method called as filter index

var myArr=[10,20,30,40,50];
var resArr2=myArr.map((item,index)=>{
    if(item >= 20)
        return item*item;
})
console.log(resArr2);
/*
[ud,400,900,1600,2500]
*/


// Destructuring of an array and obj

var n1,n2=10;
//n1 -- ud

var n3,n4=projectArr;
// n3 = ud

var [first,second]=projectArr;
//first = {projectId:"P101",projectName:"Store Front",projectDescription:"E Commerce Application"}
// second = {projectId:"P102",projectName:"CueBack",projectDescription:"Social Networking"}
// var first=projectArr[0], second=projectArr[1]

var [first1,second1,third1]=[10,20];
console.log(third1);//ud


var [first1,second1,,fourth1]=[10,20,30,40,50];
console.log(fourth1);//

// destructuring an obj

var {projectId}=first;
console.log(projectId);

// Interfaces, closures