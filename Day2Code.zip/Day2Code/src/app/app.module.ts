import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BindingExample } from './bindingExample/bindingExample.component';
import { Sample2Component } from './sample2/sample2.component';
import { BindingExample2Component } from './binding-example2/binding-example2.component';
import { BindingExample3Component } from './binding-example3.component';
@NgModule({
  declarations: [
    AppComponent,
    Sample2Component,
    BindingExample,
    BindingExample2Component,
    BindingExample3Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
