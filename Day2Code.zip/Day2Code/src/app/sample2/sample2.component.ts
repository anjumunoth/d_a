import { Component } from '@angular/core';

@Component({
  selector: 'deloitte-sample2',
  templateUrl: './sample2.component.html',
  styleUrls: ['./sample2.component.css']
})
export class Sample2Component {

}
