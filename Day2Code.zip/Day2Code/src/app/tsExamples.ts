const { createIndex } = require("mongodb/lib/operations/db_ops");
const { once } = require("nodemon");

/*var, let,const -- declare variables
var -- function scope; redeclaration allowed in the same scope
let -- block scope;redeclaration not allowed in the same scope
const -- declare a constant

Variable declarations(var,let,const) are hoisted but not initialisations
*/
const i=10;
//i=20;//error

const obj1={empId:1001,empName:"sara"};
obj1.empName="tara";//work
console.log(obj1);//{empId:1001,empName:"tara"};
//obj1={empId:1001,empName:"lara"};//error
//obj1.salary=1000;
obj1.empId="del_1001";
console.log(obj1);//{empId:1001,empName:"tara"};

function myFunction(p1,p2)
{
    var sum1=0;
    //let j=p2;
    //let j=25;
    for(let i=0;i<p1;i++)
    {
        var test1=100;
        var sum1=100;//yes
        sum1+=i;//
        let i=1;//declaration will be hoisted to top of its scope(beg of the for loop)
        
    }
    console.log("Sum1="+sum1);//
    console.log("test1="+test1);//
    //console.log("I="+i);//
}

myFunction(10,20);

class Employee{
    empId:number;
    empName:string;
    salary:number;
    
    constructor(p1:number,p2:string,p3:number)
    {
        this.empId=p1;
        this.empName=p2;
        this.salary=p3;
    }
    returnBonus():number
    {
        var bonus=this.salary*.3;
        return bonus;
    }



}


constructor
-- called implicitly 
-- called only once
-- called whenever the object is created
-- initialisation of the props
-- Multiple constructors not allowed


function myFunc(p1:number,p2:number)
{
    return p1+p2;
}

var f1=function(p1:number,p2:number)
{
    return p1+p2;
}

f1(10,20);
/*
Use case of an anonymous function
-- Pass as a parameter to another function
-- Within an object, used for declaring a function
*/

var emp1={
    empId:101,empName:"sara",
    display:function()
    {
        console.log(this.empId);
        console.log(this.empName);
    }
}

emp1.display();//101, sara
//emp1.printDetails();//error
emp1.empId=999;
//emp1.101=999;

function myFunc1(p1:number,p2:number,f1:Function) {
    f1(p1,p2);
    // addNumbers(p1,p2);
}

myFunc1(10,20,function (a1:number,a2:number){console.log(a1+a2)});// 30

myFunc1(10,20,function (b1:string,b2:string){console.log(b1+b2)});//1020 or error


var s1:number=10;
var str1:string="hello";
str1=s1.toString();


/*Lambda functions or fat arrow function
-- Special anonymous function
-- easy to write
-- Scope of "this" operator
-- this --> lexical scope (outer scope)
*/
function myFunc2(p1:number,p2:number)
{
    return p1+p2;
}

var f3=(p1:number,p2:number) => {
    return p1+p2;
}

var f4=(p1:number) => {
    return p1+p1;
}

var f5=() => {
    return "hello";
}

var f6=(p1:number) => p1+p1;

var empId=999
var emp2={
    empId:101,empName:"sara",
    display:function(){
        console.log("Inside the display")
        console.log("EmpId"+this.empId);// emp2.empId
        console.log("EmpName"+this.empName);
    },
    printDetails:()=>{
        console.log("Inside the printDetails")
        console.log("EmpId"+this.empId);;//lexical scope ; global scope
        console.log("EmpName"+this.empName);
         

    }

}

// New features in ES6

var myArr=[10,20,30,40,50];
var resArr2=myArr.map((item,index)=>{
    if(item >= 20)
        return item*item;
})
console.log(resArr2);
/*
[ud,400,900,1600,2500]
*/

var projectArr=
[{projectId:"P101",projectName:"Store Front",projectDescription:"E Commerce Application"},
{projectId:"P102",projectName:"CueBack",projectDescription:"Social Networking"},
{projectId:"P103",projectName:"Premium Access",projectDescription:"Digital Course Library"},
{projectId:"P104",projectName:"Freegal Music",projectDescription:"Libary of Songs"},
{projectId:"P105",projectName:"Comlink Data",projectDescription:"Data Science"}];

var searchElement=projectArr.find(item => item.projectId ==="100");//
console.log(searchElement);//ud

var searchElementArr=projectArr.filter(item => item.projectId ==="100");//
console.log(searchElementArr);//[]

// Destructuring of an array and obj

var n1,n2=10;
//n1 -- ud

var n3,n4=projectArr;
// n3 = ud

var [first,second]=projectArr;
//first = {projectId:"P101",projectName:"Store Front",projectDescription:"E Commerce Application"}
// second = {projectId:"P102",projectName:"CueBack",projectDescription:"Social Networking"}
// var first=projectArr[0], second=projectArr[1]

var [first1,second1,third1]=[10,20];
console.log(third1);//ud









