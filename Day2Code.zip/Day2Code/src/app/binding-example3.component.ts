import { Component } from '@angular/core';

@Component({
  selector: 'del-binding-example3',
  template: `
    <p>
      binding-example3 works!
    </p>
  `,
  styleUrls: ['./binding-example3.component.css']
})
export class BindingExample3Component {

}
