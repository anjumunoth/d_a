import {Component}  from "@angular/core";
@Component({
    selector:"app-binding",
    template:`
    <div>
        <h1> Inline template for binding example</h1>
</div>`

})
export class BindingExample
{

}

/*
Create a component manually
1. Create a folder with the name of the component inside the app folder
2. Create 2 files inside the bindingExample folder
bindingExample.component.ts
bindingExample.component.html

3. Inside the bindingExample.component.ts
a. Create a class BindingExample(pascal case) and export it
b. Add a @Component decorator
c. Pass the metadata to @Component decorator with the following mandatory fields
selector
template or templateUrl
d. Import @Component

4. Inside the bindingExample.component.html
Fill the required html

5. In the app.module.ts, add the newly created component as part of declarations in the metadata of the @Ngmodule decorator

6. Use the selector as a tag in the respective place in a html file where u want to load it
In app.component.html -- added the tag <app-binding></app-binding>

*/

/*
Easier way of creating a component
1. Open a command prompt from the project's root folder 
ng generate component bindingExample2
ng g c bindingExample2
2. Use the selector as a tag in the respective place in a html file where u want to load it
In app.component.html -- added the tag <app-binding-example2></app-binding-example2>

Some flags 
*/
