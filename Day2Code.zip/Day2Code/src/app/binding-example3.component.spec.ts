import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BindingExample3Component } from './binding-example3.component';

describe('BindingExample3Component', () => {
  let component: BindingExample3Component;
  let fixture: ComponentFixture<BindingExample3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BindingExample3Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BindingExample3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
