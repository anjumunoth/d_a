import { Directive,ElementRef,Input, OnInit} from '@angular/core';

@Directive({
  selector: '[appCustomBgColor]'
})
export class CustomBgColorDirective implements OnInit {
@Input() appCustomBgColor:string;
@Input() fontColor:string;
  constructor(private el:ElementRef) {
    console.log("El Object",this.el);
    this.appCustomBgColor="yellow";
    this.fontColor="green";
    //this.el.nativeElement.style.backgroundColor=this.appCustomBgColor;
   }

   ngOnInit(): void {
    console.log("Custom colour"+this.appCustomBgColor + "colour");// empty string if value is not passed
    if(this.appCustomBgColor == "")
    {
      this.el.nativeElement.style.backgroundColor="yellow";
    }
    else
    {
     this.el.nativeElement.style.backgroundColor=this.appCustomBgColor;
    }
    if(this.fontColor == "")
    {
      this.el.nativeElement.style.color="green";
    }
    else
    {
      this.el.nativeElement.style.color=this.fontColor;
    }
   }
   

}
