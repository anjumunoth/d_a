import { Input, SimpleChanges, Directive, ViewContainerRef, TemplateRef, OnChanges, OnInit } from '@angular/core';

@Directive({
  selector: '[appMyCustomLoop]'
})
export class MyCustomLoopDirective implements OnChanges, OnInit {
  @Input() appMyCustomLoop: Array<number>;
  constructor(private container: ViewContainerRef, private template: TemplateRef<any>) {
    this.appMyCustomLoop = [];
  }
  ngOnInit() {
    this.container.createEmbeddedView(this.template);
  }
  ngOnChanges(change: SimpleChanges) {
    this.container.clear();
    for(let i=0;i<this.appMyCustomLoop.length;i++)
    {
      this.container.createEmbeddedView(this.template);
    }

  }
}

/*
<ul>
  <li *ngFor="let num of numArr">
  {{num}}
  </li>
</ul>

<tr *ngFor="let emp of empArr">
  <td>{{emp.empId}}</td>
  <td>{{emp.empName}}></td>
</tr>
 */
