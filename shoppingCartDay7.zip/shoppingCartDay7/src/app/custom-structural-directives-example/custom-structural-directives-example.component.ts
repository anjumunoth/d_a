import { Component } from '@angular/core';

@Component({
  selector: 'app-custom-structural-directives-example',
  templateUrl: './custom-structural-directives-example.component.html',
  styleUrls: ['./custom-structural-directives-example.component.css']
})
export class CustomStructuralDirectivesExampleComponent {
  myNumbers: Array<number>;
  constructor()
  {
    this.myNumbers=[10,20,30,40];
  }
}
