import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomStructuralDirectivesExampleComponent } from './custom-structural-directives-example.component';

describe('CustomStructuralDirectivesExampleComponent', () => {
  let component: CustomStructuralDirectivesExampleComponent;
  let fixture: ComponentFixture<CustomStructuralDirectivesExampleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomStructuralDirectivesExampleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomStructuralDirectivesExampleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
