import { Component } from '@angular/core';
@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent {
  productsArr;
  colspanNumber:number;
  constructor()
  {
    this.productsArr=[
    {productId:101,productName:"Apple Mac",description:"Apple mac 128gb, white colour",price:123456,quantity:12,imgUrl:"./assets/images/macBook.jpg"},
    {productId:102,productName:"Apple Mac",description:"Apple mac 128gb, white colour",price:123456,quantity:12,imgUrl:"./assets/images/macBook.jpg"},
    {productId:103,productName:"Apple Mac",description:"Apple mac 128gb, white colour",price:123456,quantity:12,imgUrl:"./assets/images/macBook.jpg"},
    {productId:104,productName:"Apple Mac",description:"Apple mac 128gb, white colour",price:123456,quantity:12,imgUrl:"./assets/images/macBook.jpg"}]
    this.colspanNumber=4;
  }
  refreshProductsEventHandler()
  {
    this.productsArr=[
      {productId:101,productName:"Apple Mac",description:"Apple mac 128gb, white colour",price:123456,quantity:12,imgUrl:"./assets/images/macBook.jpg"},
      {productId:103,productName:"Apple Mac",description:"Apple mac 128gb, white colour",price:123456,quantity:12,imgUrl:"./assets/images/macBook.jpg"},
      {productId:105,productName:"Apple Mac",description:"Apple mac 128gb, white colour",price:123456,quantity:12,imgUrl:"./assets/images/macBook.jpg"}]
      
  }
  trackByProductId(index:number,product:any):any
  {
    return product.productId;
  }
}

/*
One way data binding
1. Interpolation
2. Property binding
3. event binding
4. Attribute binding

html element -- can have many attributes
for every html element , create a DOM object; DOM object will have some properties
Maximum properties and attributes are same 
But some attributes do not have a corresponding property : 
For these attributes - we will have to do attribute binding
*/
