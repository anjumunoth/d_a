import { MyBgColorDirective } from './my-bg-color.directive';

describe('MyBgColorDirective', () => {
  it('should create an instance', () => {
    const directive = new MyBgColorDirective();
    expect(directive).toBeTruthy();
  });
});
