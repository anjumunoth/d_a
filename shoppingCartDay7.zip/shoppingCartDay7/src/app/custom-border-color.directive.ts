import { Directive,ElementRef,Input, OnInit } from '@angular/core';

@Directive({
  selector: '[appCustomBorderColor]'
})
export class CustomBorderColorDirective implements OnInit{
@Input() appCustomBorderColor:string;
@Input() fontColor:string;
  constructor(private el:ElementRef) { 
    this.appCustomBorderColor="red";
    this.fontColor="red";

  }
  ngOnInit(): void {
    this.el.nativeElement.style.color=this.fontColor || "yellow";
    this.el.nativeElement.style.borderColor=this.appCustomBorderColor || "red";
  }
  

}
