import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildTemplateExampleComponent } from './child-template-example.component';

describe('ChildTemplateExampleComponent', () => {
  let component: ChildTemplateExampleComponent;
  let fixture: ComponentFixture<ChildTemplateExampleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChildTemplateExampleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChildTemplateExampleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
