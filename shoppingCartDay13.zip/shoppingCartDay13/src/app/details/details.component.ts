import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit, OnDestroy {
  productId:string | null;
  pmSubscription:any;
  constructor(private activateRoute:ActivatedRoute,private router:Router)
  {
    this.productId=""
  }
  ngOnInit(){
    console.log("Activated Route details",this.activateRoute);
    /* // Using the snapshot method
    this.productId=this.activateRoute.snapshot.paramMap.get('pId');
    this.productId=this.activateRoute.snapshot.params['pId']; */

    this.pmSubscription=this.activateRoute.paramMap
    .subscribe(
      params =>{
        console.log(params);
        this.productId=params.get('pId');
      }
    )

  }
  ngOnDestroy(): void {
    if(this.pmSubscription)
    {
      this.pmSubscription.unsubscribe();
    }
  }

  backEventHandler()
  {
    this.router.navigate(['products']);
  }
  
}
