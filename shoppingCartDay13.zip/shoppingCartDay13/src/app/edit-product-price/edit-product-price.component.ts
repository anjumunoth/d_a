import { Component,Input } from '@angular/core';
import { Products } from '../products';

@Component({
  selector: 'app-edit-product-price',
  templateUrl: './edit-product-price.component.html',
  styleUrls: ['./edit-product-price.component.css'],
  inputs:['companyName']
})
export class EditProductPriceComponent {
  companyName:string;
  private _selectedProduct:Products| null;
@Input()
public get selectedProduct()
{
  return this._selectedProduct;
}
public set selectedProduct(value)
{
  this._selectedProduct=value;
  if(this._selectedProduct && value)
    this._selectedProduct.price=value.price*75;

}
myString:string;
temp:boolean;

constructor()
{
  this._selectedProduct=null;
  this.myString="hello";
  this.temp=true;
  this.companyName="";
}
}
