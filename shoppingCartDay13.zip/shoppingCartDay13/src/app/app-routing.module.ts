import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CartComponent } from './cart/cart.component';
import { DetailsComponent } from './details/details.component';
import { EditProductComponent } from './edit-product/edit-product.component';
import { FilterProductsComponent } from './filter-products/filter-products.component';
import { HomeComponent } from './home/home.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { PaymentByCardComponent } from './payment-by-card/payment-by-card.component';
import { PaymentByCODComponent } from './payment-by-cod/payment-by-cod.component';
import { PaymentByNetBankingComponent } from './payment-by-net-banking/payment-by-net-banking.component';
import { PaymentByWalletComponent } from './payment-by-wallet/payment-by-wallet.component';
import { PaymentOptionsComponent } from './payment-options/payment-options.component';
import { RegisterComponent } from './register/register.component';
import { TemplateExamplesComponent } from './template-examples/template-examples.component';
import { UsersManagementComponent } from './users-management/users-management.component';

// first match wins strategy; first give specified routes, then give generalised ones
const routes: Routes = [
  {path:"products",component:HomeComponent},
  {path:"register",component:RegisterComponent},
  {path:"users",component:UsersManagementComponent},
  {path:"cart",component:CartComponent},
  {path:"details/:pId/category/:categoryName",component:TemplateExamplesComponent},
  {path:"details/:pId",component:DetailsComponent},
  {path:"filter/:pName/category/:categoryName",component:FilterProductsComponent},
  {path:"edit-product",component:EditProductComponent},
  {path:"payment",component:PaymentOptionsComponent,
  children:[
    {path:"card",component:PaymentByCardComponent},
    {path:"cod",component:PaymentByCODComponent},
    {path:"wallet",component:PaymentByWalletComponent},
    {path:"netBanking",component:PaymentByNetBankingComponent},
  ]
},
  {path:"",redirectTo:"/products",pathMatch:"full"},
  {path:"**",component:PageNotFoundComponent}
];
// details/100 -- DetailsComponent
//details/100/category/77 -- TemplateExamplesComponent
//details -- pageNotFound
//details/100/category -- pageNotFound
// 

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
