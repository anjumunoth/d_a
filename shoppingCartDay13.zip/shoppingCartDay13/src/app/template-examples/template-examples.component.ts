import { Component } from '@angular/core';

@Component({
  selector: 'app-template-examples',
  templateUrl: './template-examples.component.html',
  styleUrls: ['./template-examples.component.css']
})
export class TemplateExamplesComponent {
  items: Array<any>;
  defaultEmp:Object;
  constructor()
  {
    this.defaultEmp={empId:777,empName:"Asha",salary:5678};
    this.items=[
      {name:"Angular",active:true},
      {name:"React",active:false},
      {name:"Nodejs",active:true},
      {name:"Mongodb",active:false},
      {name:"Dynamodb",active:false},
      {name:"Vue",active:true},
    ]
  }
}
