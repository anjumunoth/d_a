export class CartProduct {
    productId:number;
    productName:string;
    price:number;
    description:string;
    quantity:number;
    imgUrl:string;
    quantitySelected?:number;
    constructor(productId:number,productName:string,description:string, price:number,quantity:number,imgUrl:string,quantitySelected:number)
    {
        this.productId=productId;
        this.productName=productName;
        this.price=price;
        this.description=description;
        this.quantity=quantity;
        this.imgUrl=imgUrl;
        this.quantitySelected=quantitySelected;
    }
}
