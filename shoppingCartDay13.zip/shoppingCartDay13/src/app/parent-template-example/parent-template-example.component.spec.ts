import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParentTemplateExampleComponent } from './parent-template-example.component';

describe('ParentTemplateExampleComponent', () => {
  let component: ParentTemplateExampleComponent;
  let fixture: ComponentFixture<ParentTemplateExampleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ParentTemplateExampleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ParentTemplateExampleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
