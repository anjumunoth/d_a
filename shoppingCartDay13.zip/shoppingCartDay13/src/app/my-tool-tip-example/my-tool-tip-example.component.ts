import { Component } from '@angular/core';

@Component({
  selector: 'app-my-tool-tip-example',
  templateUrl: './my-tool-tip-example.component.html',
  styleUrls: ['./my-tool-tip-example.component.css']
})
export class MyToolTipExampleComponent {
  customText:string;
  ctr:number;
  constructor()
  {
    this.customText="Increment counter";
    this.ctr=1;
  }
  incCtrEventHandler()
  {
    
    if(this.ctr == 5)
    {
      this.customText="Reached max value";
    
    }
    else
    {
      this.ctr++;
    }
  }

}
