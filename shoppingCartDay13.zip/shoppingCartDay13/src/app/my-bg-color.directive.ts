import { Directive,ElementRef } from '@angular/core';

@Directive({
  selector: '[appMyBgColor]'
})
export class MyBgColorDirective {

  constructor(private el:ElementRef) { 
    this.el.nativeElement.style.backgroundColor="pink";
    this.el.nativeElement.style.border="5px double red"
    this.el.nativeElement.style.color="red";
  }

}
