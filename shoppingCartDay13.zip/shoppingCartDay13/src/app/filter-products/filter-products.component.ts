import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';

@Component({
  selector: 'app-filter-products',
  templateUrl: './filter-products.component.html',
  styleUrls: ['./filter-products.component.css']
})
export class FilterProductsComponent implements OnInit {
  productName:string |null="";
  category:string |null="";
  constructor(private activatedRoute:ActivatedRoute,private router:Router)
  {

  }
  ngOnInit(): void {
    this.productName=this.activatedRoute.snapshot.paramMap.get('pName')
    this.category=this.activatedRoute.snapshot.paramMap.get('categoryName')
  }


}
