import { Injectable } from '@angular/core';
import { Users } from './users';
@Injectable()
export class UserManagementService {
  user: Users | null;
  userArr: Array<Users>;
  constructor() {
    this.user = null;
    this.userArr = [];
  }
  createNewUser(userName: string, password: string, emailId: string) {
    this.user = new Users(userName, password, emailId);
    return this.user;
  }
  saveUser() {
    // async call to save the user details in the db
    if (this.user) {
      var userStatus = this.checkIfUserExists(this.user);
      if (userStatus === false) {
        this.userArr.push(this.user);
        return true;
      }
    }

    return false;
  }
  checkIfUserExists(checkUser: Users) {
    var pos = this.userArr.findIndex(item => item.userName === checkUser.userName)
    if (pos >= 0) {
      return true;
    }
    // async call to the server to check if user exists
    return false;
  }


}

/*
Inject service at the app level 
@Injectable({providedIn:"root"})


Inject service at the module level -- only available in that specific module
In the corresponding module level
@NgModule({
  providers:["name of the service"]
})


Inject service at the component level
In the corresponding component file
@Component({
  providers:["name of the service"]
})

Inject service at the directive level
In the corresponding directive file
@Directive({
  providers:["name of the service"]
})


*/
