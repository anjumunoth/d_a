import { PasswordMustMatchDirective } from './password-must-match.directive';

describe('PasswordMustMatchDirective', () => {
  it('should create an instance', () => {
    const directive = new PasswordMustMatchDirective();
    expect(directive).toBeTruthy();
  });
});
