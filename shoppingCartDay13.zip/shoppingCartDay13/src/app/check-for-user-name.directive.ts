import { Directive } from '@angular/core';
import { NG_VALIDATORS } from '@angular/forms';
import {checkForUserName} from "./Validators/checkForUserName.validator"

@Directive({
  selector: '[appCheckForUserName]',
  providers:[{
    provide:NG_VALIDATORS,
    useValue:checkForUserName,
    multi:true
  }]
})
export class CheckForUserNameDirective {

  constructor() { }

}
