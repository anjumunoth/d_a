import { CheckForUserNameDirective } from './check-for-user-name.directive';

describe('CheckForUserNameDirective', () => {
  it('should create an instance', () => {
    const directive = new CheckForUserNameDirective();
    expect(directive).toBeTruthy();
  });
});
