export class Users {
    constructor(public userName?:string,public password?:string,public emailId?:string)
    {
    }
}
