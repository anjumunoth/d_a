import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { TalkWithServerService } from '../talk-with-server.service';
import { interval, take, lastValueFrom } from 'rxjs';

@Component({
  selector: 'app-users-management',
  templateUrl: './users-management.component.html',
  styleUrls: ['./users-management.component.css']
})
export class UsersManagementComponent implements OnInit{
    usersArr:any[];
    usersArrObservable$:Observable<any[]>;
    showAddUser:boolean;
    getSuccess:boolean;
    constructor(public talkWithServer:TalkWithServerService)
    {
      this.usersArr=[];
      this.usersArrObservable$=new Observable();
      this.showAddUser=false;
      this.getSuccess=false;
    }

    ngOnInit(): void {
      this.talkWithServer.getUsers()
      .subscribe((response)=>{
        console.log(response.data)
         this.usersArr=response.data;
      })

      this.usersArrObservable$=this.talkWithServer.getUsersFromJsonPlaceHolder();
    }
    addUserEventHandler()
    {
      this.showAddUser=true;
    }
    confirmAddUserEventHandler(username:string,email:string)
    {
      this.showAddUser=false;
      var user={email:email,name:username};
      this.talkWithServer.addUser(user)
      .subscribe(
        (res)=>{
          console.log("Response from post request",res);
          alert("User added successfully");
          // write here the next api request
          //call the method 
          // put request
          //this.getSuccess=true;
          // call a new method where the request can be sent from

        }
      )

      
    }

    async confirmAddUserEventHandlerAsPromise(username:string,email:string)
    {
      this.showAddUser=false;
      var user={email:email,name:username};
      var newUser=await lastValueFrom(this.talkWithServer.addUser(user));
      console.log("New user details from promise",newUser)
      this.usersArr=await lastValueFrom(this.talkWithServer.getUsers());
    }


}
