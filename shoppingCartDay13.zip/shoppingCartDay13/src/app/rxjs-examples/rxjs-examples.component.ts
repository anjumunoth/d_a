import { Component } from '@angular/core';
import { from, Observable } from 'rxjs';
import { filter, map, take } from "rxjs/operators"
import { Products } from '../products';

@Component({
  selector: 'app-rxjs-examples',
  templateUrl: './rxjs-examples.component.html',
  styleUrls: ['./rxjs-examples.component.css']
})
export class RxjsExamplesComponent {
  myObservable: Observable<number>;
  takeObservable: Observable<number>;
  sqObservable: Observable<number>;
  myObservable1: Observable<number>;
  serverDataObservable:Observable<object>;

  time$:Observable<string>;
  //productsArr:Observable<object[]>;

  constructor() {
    /* this.productsArr=new Observable<object[]>(
      ()=>{
        var serverUrl="https://jsonplaceholder.typicode.com/posts"
    
        return from(fetch(serverUrl)).pipe(
          map(item => item.json())
        )
      }
    );
    */
    this.time$ = new Observable<string>(observer => {
      setInterval(() => observer.next(new Date().toString()), 1000);
    });
   
    this.serverDataObservable=new Observable<object>();
    this.myObservable = from([1, 2, 3, 4, 5, 6, 7]).pipe(
      filter(item => item % 2 === 0)
    )

    this.myObservable1 = from([1, 2, 3, 4, 5, 6, 7]).pipe(
      filter(item => item % 2 !== 0)
    )

    this.sqObservable = from([1, 2, 3, 4, 5]).pipe(
      map(item => item * item)
    )
    this.takeObservable = from([1, 2, 3, 4, 5]).pipe(
      take(3),
      map(item => item * item)
    )
  }
  subscribeEventHandler() {
    this.myObservable.subscribe(
      (data) => {
        console.log("Data received from the observable and first observer", data);
      })

    this.myObservable.subscribe(
      (data) => {
        console.log("Data received from the observable and second observer", data);
      })

    this.sqObservable.subscribe(
      (data) => {
        console.log("Data from the square observable", data);
      }
    )

    this.takeObservable.subscribe(
      (data) => {
        console.log("Data from the take observable", data);
      }
    )

    this.myObservable1.subscribe({
      next: (data) => {
        console.log("Data from the myObservable1 observable", data);
      },
      error: (err) => {
        console.log("Error", err)
      },
      complete: () => {
        console.log("Data stream complete");
      }
    })


    const observable = new Observable(subscriber => {
      subscriber.next(1); // pushes a value

      subscriber.next(2); // pushes another value synchronously
      setTimeout(() => {
        subscriber.next(3); // pushes last value after a wait of 1s
        subscriber.complete(); // terminates observable stream
      }, 1000);
    });
    /* Subscribing to an observable */
    console.log('just before subscribe');

const subscription = observable.subscribe({
      // The three possible output captures:
      next(x) { console.log('got value ' + x); },
      error(err) { console.error('something wrong occurred: ' + err); },
      complete() { console.log('done'); }
    }); // creates subscription object

    console.log('just after subscribe');

    /* Unsubscribing to an observable using subscription */
    setTimeout(() => {
      subscription.unsubscribe();
    }, 500);




  }
  getDataFromServer()
  {
    var serverUrl="https://jsonplaceholder.typicode.com/posts"
    fetch(serverUrl)
      .then(response => response.json())
      .then(json => console.log(json))

    this.serverDataObservable=from(fetch(serverUrl)).pipe(
      take(5),
      map(item => item.json())
    )

    this.serverDataObservable.subscribe({
      next:(data)=>{
        setTimeout(()=>{
          console.log("Data from the server",data);
        },4000)

    }
    ,
    complete:()=>{
      console.log("Stream complete")
    }
  })
      
  }
  

}
