import { AbstractControl, FormControl, FormGroup } from "@angular/forms";

export function passwordMustMatchValidator(controlName:string,matchingControlName:string)
{
    return (
        (formGroup:AbstractControl| any)=>{
            console.log("FormGroup",formGroup);
            //obj.fieldName; obj['fieldName]
            const control=formGroup?.controls[controlName];
            const matchingControl=formGroup?.controls[matchingControlName]
            if( !control || !matchingControl)
            {
                // not initialised or not set
                return null;
            }
             if(control.errors || matchingControl.errors)
            {
                // if there are any others errors
                return null;
            } 
           

            if(control.value !== matchingControl.value)
            {
                matchingControl.setErrors({passwordMustMatch:true});
                return ({passwordMustMatch:true});
            }
            else
            {
                matchingControl.setErrors(null);
                return null;
            }

        }
    )
}