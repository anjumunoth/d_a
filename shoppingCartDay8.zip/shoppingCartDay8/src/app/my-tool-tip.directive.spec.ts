import { MyToolTipDirective } from './my-tool-tip.directive';

describe('MyToolTipDirective', () => {
  it('should create an instance', () => {
    const directive = new MyToolTipDirective();
    expect(directive).toBeTruthy();
  });
});
