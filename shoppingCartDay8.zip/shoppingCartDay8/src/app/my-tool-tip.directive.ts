import { Directive, Input, ElementRef, Renderer2, HostListener } from '@angular/core';

@Directive({
  selector: '[appMyToolTip]'
})
export class MyToolTipDirective {
  elToolTip: any;
  @Input() toolTipText: string;
  @HostListener('mouseenter') onMouseEnter() {
    if(!this.elToolTip)
    {
      this.showHint();
    }
  }
  @HostListener('mouseleave') onMouseLeave() {
    if (this.elToolTip) {
      this.removeHint()
    }
  }
  constructor(private element: ElementRef, private renderer: Renderer2) {
    this.toolTipText = "";
    this.elToolTip = "";
  }
  showHint() {
    this.elToolTip = this.renderer.createElement("span");
    const textElement = this.renderer.createText(this.toolTipText);
    this.renderer.appendChild(this.elToolTip, textElement);

    this.renderer.appendChild(document.body, this.elToolTip);

    let hostPos = this.element.nativeElement.getBoundingClientRect();

    let top = hostPos.bottom + 10;
    let left = hostPos.left;

    this.renderer.addClass(this.element.nativeElement,"h1BgColorRed");
    this.renderer.setStyle(this.elToolTip, 'top', `${top}px`);
    this.renderer.setStyle(this.elToolTip, 'left', `${left}px`);
    this.renderer.setStyle(this.elToolTip, 'position', 'absolute');
    this.renderer.setStyle(this.elToolTip, 'display', 'inline-block');
    this.renderer.setStyle(this.elToolTip, 'background-color', 'yellow');
    this.renderer.setStyle(this.elToolTip, 'z-index', '1000');

  }
  removeHint() {
    this.renderer.removeChild(document.body, this.elToolTip);
    this.elToolTip = null;

  }

}
