import { Component,Input, OnInit } from '@angular/core';
import { Products } from '../products';

@Component({
  selector: 'app-add-to-cart',
  templateUrl: './add-to-cart.component.html',
  styleUrls: ['./add-to-cart.component.css']
})
export class AddToCartComponent implements OnInit {
  @Input() selProduct:Products| any;
  quantitySelected:number;
  constructor()
  {
    this.selProduct={};
    console.log("Inside the constructor");
    console.log("Selected Product : ",this.selProduct);
    //Is the constructor executed or not -- Yes 
    // If yes, what will the console.log print -- Empty object
    this.quantitySelected=1;


  }
  ngOnInit(): void {
    console.log("Inside ngOnInit Selected product :",this.selProduct);
  }
}

/*
This is a child component
Is going to receive some data / some input from the parent -- via the properties
selProduct -- property name


Lifecycle methods
-- Called implicitly
-- Never called explicitly
-- Each method is invoked at a particular point of time
-- Some lifecycle methods which are called only once during the entire lifetime-- constructor, destructor(ngDestroy)
-- Some lifecycle methods which are invoked multiple times
-- constructor -- invoked only once; first lifecycle method to be invoked; initialise the properties


User click on add to cart button --> showAddToCart -- true 
--> addtoCart component is loaded/mounted 
--> constructor is called 
--> data received from the parent is assigned to the input decorator variables
--> load the corresponding template

User is changing the data flowing from parent to child
-- AddToCart is already loaded
--Click on another product's addToCart
--> No unmounting/mounting of AddToCart happens
--> no constructor is called
--> data received from the parent is assigned to the input decorator variables
--> populate the corresponding template

ngOnInit()
-- Called only once
-- Called after the constructor and after the @Input assignments


*/
