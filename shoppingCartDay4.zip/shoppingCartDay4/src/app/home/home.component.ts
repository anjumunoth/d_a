import { Component } from '@angular/core';
import { Products } from '../products';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  productsArr:Products[];
  colours:string[];
  showAddToCart:boolean;
  showDetails:boolean;
  selectedProduct:Products| any;
  constructor()
  {
    this.productsArr=[];
    this.productsArr.push(new Products(101,"Apple Mac","Apple mac 128gb, white colour",123456,12,"./assets/images/macBook.jpg"));
    this.productsArr.push(new Products(102,"Dell Latitude","Dell Latitude, white colour",111111,2,"./assets/images/dellLatitude.jpg"));
    this.productsArr.push(new Products(103,"Lenovo Idea Pad","Lenovo Idea Pad 128gb, white colour",73456,5,"./assets/images/lenovoIdeaPad.jpg"));
    this.productsArr.push(new Products(104,"Samsung Galaxy Book","Samsung Galaxy Book 128gb, white colour",122222,12,"./assets/images/samsunggalaxyBook.jpg"));
    this.colours=["red","green","blue"];
    this.showAddToCart=false;
    this.showDetails=false;
    this.selectedProduct={};

  }
  addToCartEventHandler(selectedProduct:Products)
  {
    alert("Button clicked on product with productId : " +selectedProduct.productId);
    this.showAddToCart=true;
    this.selectedProduct=selectedProduct;
  }
  showSelectedProductEventHandler()
  {
    this.showDetails=true;
    this.selectedProduct=this.productsArr[0];
  }
  closeEventHandler()
  {
    this.showDetails=false;
  }  

}

/*
data about the various products -- server
static data

Directives
1. Structural Directive
2. Attribute Directive
3. Custom directives

Components:
-- Class with component Decorator
-- Component has to be enclosed within a module
-- Independent building block with a view associated
-- Web page can consist of multiple components
-- Each component occupy a part of view of web page
-- Special Directive with an associated view

Structural Directive -- Directive which will change the structure of the DOM
1. ngFor --
2. ngIf

Parent --> child communication
Similar to property binding
Enclosed the property within square brackets



*/
