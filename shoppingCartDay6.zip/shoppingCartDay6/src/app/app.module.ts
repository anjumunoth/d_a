import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { AddProductComponent } from './add-product/add-product.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { EditProductComponent } from './edit-product/edit-product.component';
import { EditProductPriceComponent } from './edit-product-price/edit-product-price.component';
import { AddToCartUsingGetSetComponent } from './add-to-cart-using-get-set/add-to-cart-using-get-set.component';
import { AttrDirectiveExampleComponent } from './attr-directive-example/attr-directive-example.component';
import { PaymentOptionsComponent } from './payment-options/payment-options.component';
import { PaymentByCODComponent } from './payment-by-cod/payment-by-cod.component';
import { PaymentByCardComponent } from './payment-by-card/payment-by-card.component';
import { PaymentByWalletComponent } from './payment-by-wallet/payment-by-wallet.component';
import { PaymentByNetBankingComponent } from './payment-by-net-banking/payment-by-net-banking.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    AddProductComponent,
    AddToCartComponent,
    EditProductComponent,
    EditProductPriceComponent,
    AddToCartUsingGetSetComponent,
    AttrDirectiveExampleComponent,
    PaymentOptionsComponent,
    PaymentByCODComponent,
    PaymentByCardComponent,
    PaymentByWalletComponent,
    PaymentByNetBankingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
