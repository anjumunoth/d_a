import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AttrDirectiveExampleComponent } from './attr-directive-example.component';

describe('AttrDirectiveExampleComponent', () => {
  let component: AttrDirectiveExampleComponent;
  let fixture: ComponentFixture<AttrDirectiveExampleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AttrDirectiveExampleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AttrDirectiveExampleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
