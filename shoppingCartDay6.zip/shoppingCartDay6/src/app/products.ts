export class Products {
    productId:number;
    productName:string;
    price:number;
    description:string;
    quantity:number;
    imgUrl:string;
    constructor(productId:number,productName:string,description:string, price:number,quantity:number,imgUrl:string)
    {
        this.productId=productId;
        this.productName=productName;
        this.price=price;
        this.description=description;
        this.quantity=quantity;
        this.imgUrl=imgUrl;
    }
}
