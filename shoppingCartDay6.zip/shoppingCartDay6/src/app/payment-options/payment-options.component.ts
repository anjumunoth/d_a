import { Component } from '@angular/core';

@Component({
  selector: 'app-payment-options',
  templateUrl: './payment-options.component.html',
  styleUrls: ['./payment-options.component.css']
})
export class PaymentOptionsComponent {
  selectedValue:string;
  paymentOptionsArr:Array<string>;
  selectedPaymentOption:string;

  constructor()
  {
    this.paymentOptionsArr=["card","COD","Wallet","Net Banking"];
    this.selectedPaymentOption=this.paymentOptionsArr[0];
    this.selectedValue=this.paymentOptionsArr[0]
  }
  updateSelectedPaymentOption(){
    this.selectedPaymentOption=this.paymentOptionsArr[0];
  }
}
