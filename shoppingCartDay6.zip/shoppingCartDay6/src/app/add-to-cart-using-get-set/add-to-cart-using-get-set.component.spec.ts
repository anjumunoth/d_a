import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddToCartUsingGetSetComponent } from './add-to-cart-using-get-set.component';

describe('AddToCartUsingGetSetComponent', () => {
  let component: AddToCartUsingGetSetComponent;
  let fixture: ComponentFixture<AddToCartUsingGetSetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddToCartUsingGetSetComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddToCartUsingGetSetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
